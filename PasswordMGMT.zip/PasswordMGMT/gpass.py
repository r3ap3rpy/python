from getpass import getpass

def GetPassword(msg):
	pwd = getpass(msg)
	return str(pwd).encode('utf-8')
