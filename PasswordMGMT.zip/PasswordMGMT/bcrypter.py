import bcrypt
from gpass import GetPassword
from CacheHouse import Password

def VerifyPassword(goodPassword, givenPassword):
	HashedValue = bcrypt.hashpw(givenPassword, bcrypt.gensalt())
	return bcrypt.checkpw(goodPassword,HashedValue)

while True:
	WantToVerify = input('Which account would you like to verify ({}):'.format(','.join(Password.keys())))
	if WantToVerify in Password.keys():
		break


if VerifyPassword(Password[WantToVerify],GetPassword('Please give me the password:')):
	print('Your password for your {} was verified successfully!'.format(WantToVerify))
else:
	print('Your password for your {} could not be verified!'.format(WantToVerify))