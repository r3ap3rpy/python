Password = {
	'bankaccount':b'bankaccountpwd',
	'fbookaccount':b'fbookpassword',
	'schoolaccount':b'schoolpassword'
}