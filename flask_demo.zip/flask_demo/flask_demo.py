from flask import Flask, render_template
import os

app = Flask(__name__)

@app.route("/")
@app.route("/<key>/<value>", methods = ['GET'])
def index(key = None, value = None):
	return render_template('index.html', arguments=[key, value])

@app.route("/theother")
def theother():
	return render_template('theother.html')


if __name__ == '__main__':
	import ssl
	CRT = os.sep.join(['SSL','flask_demo.crt'])
	KEY = os.sep.join(['SSL','flask_demo.key'])

	context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
	context.load_cert_chain(CRT,KEY)

	app.run(host='0.0.0.0', debug=True, port=8080, ssl_context=context)