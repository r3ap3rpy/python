from flask import Flask, render_template, request
from functools import wraps
import os
import json
import sys
sys.path.extend(['modules'])
import Authenticator

Auth = Authenticator.Authenticator()
app = Flask(__name__)

def check_authentication(username,password):
	return username == Auth.auth['Username'] and password == Auth.auth['Password']

def authenticate():
	return (
		'Could not verify your authority\n',
		'Please provide valid credentials in order to get pass!\n',
		{'WWW-Authenticate':'Basic realm = "Login Required"'})

def requires_auth(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		auth = request.authorization
		if not auth or not check_authentication(auth.username,auth.password):
			return authenticate()
		return f(*args,**kwargs)
	return decorated

@app.route("/")
@app.route("/<key>/<value>", methods = ['GET'])
def index(key = None, value = None):
	return render_template('index.html', arguments=[key, value])

@app.route("/theother")
def theother():
	return render_template('theother.html')

ResponseCache = {}
@app.route("/authentication/<pid>")
@requires_auth
def authorized_access(pid = None):
	if ResponseCache.get(pid):
		print('Answering from cache: {}'.format(ResponseCache[pid]))
		return json.dumps(ResponseCache[pid])
	else:
		print('First evre asked: {}'.format(pid))
		if Auth.credentials.get(pid):
			Reponse = dict({'Status':'OK','Password':Auth.credentials.get(pid)})
		else:
			Reponse = dict({'Status':'ERROR','Password':'Cache Miss'})
		ResponseCache.update({pid:Reponse})
	return json.dumps(Reponse)
	return 'This part comes after proper authentication!'


if __name__ == '__main__':
	import ssl
	CRT = os.sep.join(['SSL','flask_demo.crt'])
	KEY = os.sep.join(['SSL','flask_demo.key'])

	context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
	context.load_cert_chain(CRT,KEY)
	app.run(host='0.0.0.0', debug=True, port=8080, ssl_context=context)