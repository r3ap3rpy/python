class Authenticator(object):
	__auth = {'Username':'poweruser','Password':'Password123'}
	__credentials = {
		None : 'Unicorns fly so high!',
		'666' : 'Pow3rPuffGurlz!!!',
		'111' : 'Password123',
		'222' : 'Password222',
		'333' : ''
	}

	@property
	def auth(self):
		return self.__auth

	@property
	def credentials(self):
		return self.__credentials

if __name__ == '__main__':
	Auth = Authenticator()
	print(Auth)
	print(Auth.auth)
	print(Auth.credentials)